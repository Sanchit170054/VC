
<?php
if(isset($_POST['submit'])){
   
    $uID = $_POST['userID'];
    $Userpass = $_POST['pass'];
   
    $host = "localhost: 3306";
    $dbUsername = "root";
    $dbPassword = "";
	$dbname = "communityDB";

        $connect = new mysqli($host,$dbUsername,$dbPassword, $dbname);
        if($connect->connect_error){
            echo "<script type='text/javascript'>alert('Error: Connection is failed..!');</script>";
           
        }
		
         $SELECT = "select * from userdata where userID='".$uID."'";
		 $result = $connect->query($SELECT);
		 
		 if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				
				if($row['userID']==$uID && $row['password']==$Userpass){
				 echo "<script type='text/javascript'>alert('Hi $row[userName], Welcome to our Community..!');</script>";
					echo "<script> window.location.assign('dashboard.html'); </script>";
        
		 
				} else {
				 echo "<script type='text/javascript'>alert('invalid Credentias...!');</script>";
					echo "<script> window.location.assign('login.php'); </script>";
				  exit();
				}
				
			}
		 }

	}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Login</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="assets/css/Footer-Clean.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="height: 615px;">
    <div>
        <div class="header-dark" style="height: 187px;background-image: url(&quot;assets/img/mountain_bg.jpg&quot;);">
            <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
                <div class="container"><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse text-uppercase" id="navcol-1"><img class="mr-auto" src="assets/img/logo.png" onClick="location.href='mainpage.html'"style="height: 144px;"><span class="ml-auto navbar-text"></span><a class="btn btn-light action-button" role="button" href="signUp.php">Sign Up</a></div>
                </div>
            </nav>
        </div>
    </div>
    <div class="bounce animated" style="margin-top: 60px;">
        <div class="container">
            <div class="row">
                <div class="col-md-6" style="height: 467px;">
                    <div class="row">
                        <div class="col"><i class="fa fa-lock" style="font-size: 150px;margin-left: 164px;color: rgb(39,113,187);"></i></div>
                    </div>
                    <div class="row">
                        <div class="col"><label style="font-size: 42px;color: rgb(44,125,205);">Log in to your network</label>
                            <form name="myForm" action="" method="post">
								<div class="row" style="margin-top: 16px;"><label style="font-size: 22px;color: rgb(1,8,16);margin-left: 50px;">User ID:&nbsp;<input class="border rounded form-control-lg" type="text" name = "userID" style="background-color: rgb(255,254,254);margin-left: 18px;" autocomplete="on" required="" minlength="1" maxlength="10" autofocus=""></label></div>
								<div
                                class="row">
                                <div class="col" style="margin-top: 16px;"><label style="font-size: 22px;margin-left: 32px;">Password:&nbsp;</label><input class="border rounded form-control-lg" type="text" name = "pass" style="background-color: rgb(255,254,254);margin-left: 1px;" autocomplete="on" required=""
                                        minlength="1" maxlength="10" autofocus="">
										
                                    <div class="row" style="margin-top: 30px;">
                                        <div class="col" style="padding-left: 218px;">
										 <input type="submit" name="submit" value="Login" style="background-color: rgb(30,169,69);font-size: 22px;" /></div>

									</div>
									<div class="col" style="padding-left: 150px; margin-top: 20px"><a href="signUp.php" style="font-size: 18px; margin-left: 20px;">Forgot Password ?&nbsp;</a></div>
										
                                </div>
								
								
							</form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <section>
                    <div class="row">
                        <div class="col" style="background-color: #0f58b5;"><img class="shadow" src="assets/img/login.png" style="width: 530px;height: 299px;"><label style="font-size: 26px;color: rgb(201,207,220);">Share your knowledge and gain from the best</label>
                            <p style="font-size: 24px;margin-top: 19px;color: rgb(239,243,247);">Our Community is the easiest way to connect with the best people from around your organization and grow your knowledge!<br></p>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
	
	
	<script>

	
</script>
</body>

</html>