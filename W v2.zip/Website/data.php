<?php
	if (isset($_POST['getData'])) {
		$conn = new mysqli('localhost: 3306', 'root', '', 'infinite_scroll');

		$start = $conn->real_escape_string($_POST['start']);
		$limit = $conn->real_escape_string($_POST['limit']);

		$sql = $conn->query("SELECT name, about FROM country LIMIT $start, $limit");
		if ($sql->num_rows > 0) {
			$response = "";

			while($data = $sql->fetch_array()) {
				$response .= '
					<div style= "background-color: lightgrey; border-bottom: 6px solid blue; border-radius: 8px; margin-top: 50px">
						<h2>'.$data['name'].'</h2>
						<p>'.$data['about'].'</p>
						<div >
						<button class="btn btn-primary" type="button" style="font-size: 18px;">Like Post&nbsp;<i class="icon ion-android-arrow-forward">
						<button class="btn btn-primary" type="button" style="	font-size: 18px; margin-top: -70px; margin-left: 387px"> Comment Post&nbsp;<i class="icon ion-android-arrow-forward">
						
						</div>
					</div>
				';
			}

			exit($response);
		} else
			exit('reachedMax');
	}
?>