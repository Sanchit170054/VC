<?php

    $uName = $_POST['userName'];
    $uID = $_POST['userID'];
    $Umail = $_POST['mail'];
    $Phnumber = $_POST['number'];
    $Userpass = $_POST['pass'];
    $conFPass = $_POST['confirmPass'];
    $Udepartment = $_POST['dept'];
    $add = $_POST['user_Add'];
    

    $host = "localhost: 3306";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "communityDB";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT userID From userdata Where userID = ? Limit 1";
     $INSERT = "INSERT Into userdata (userName, userID, Email, phoneNumber, password, confirmPassword, department, address) 
     values(?, ?, ?, ?, ?, ?, ?, ? )";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $uID);
     $stmt->execute();
     $stmt->bind_result($uID);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("sssisssss", $uName, $uID, $Umail, $Phnumber, $Userpass, $conFPass, $Udepartment, $add);
      $stmt->execute();
      echo "<script type='text/javascript'>alert('Registration successfull..!');</script>";
         
     } else {
        echo "<script type='text/javascript'>alert('Someone is already registered with this ID');</script>";
           
     }
     $stmt->close();
     $conn->close();
    }


?>
