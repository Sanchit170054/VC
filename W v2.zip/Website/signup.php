
<?php
if(isset($_POST['submit'])){
   
    $uName = $_POST['userName'];
    $uID = $_POST['userID'];
    $Umail = $_POST['mail'];
    $Phnumber = $_POST['number'];
    $Userpass = $_POST['pass'];
    $conFPass = $_POST['confirmPass'];
    $Udepartment = $_POST['dept'];
    $add = $_POST['user_Add'];
	

    $host = "localhost: 3306";
    $dbUsername = "root";
    $dbPassword = "";
	$dbname = "communityDB";

        $connect = new mysqli($host,$dbUsername,$dbPassword, $dbname);
        if($connect->connect_error){
            echo "<script type='text/javascript'>alert('Error: Connection is failed..!');</script>";
           
        }
        
         $SELECT = "SELECT userID From userdata Where userID = ? Limit 1";
        $INSERT = "INSERT Into userdata (userName, userID, Email, phoneNumber, password, confirmPassword, department, address) 
        values(?, ?, ?, ?, ?, ?, ?, ?)";
        //Prepare statement
        $stmt = $connect->prepare($SELECT);
        $stmt->bind_param("s", $uID);
        $stmt->execute();
        $stmt->bind_result($uID);
        $stmt->store_result();
        $rnum = $stmt->num_rows;
        if ($rnum==0) {
         $stmt->close();
         $stmt = $connect->prepare($INSERT);
         $stmt->bind_param("sssissss", $uName, $uID, $Umail, $Phnumber, $Userpass, $conFPass, $Udepartment, $add);
         $stmt->execute();
         echo "<script type='text/javascript'>alert('Registration successfull..!');</script>";
		   echo "<script> window.location.assign('login.php'); </script>";
        
         } else {
           echo "<script type='text/javascript'>alert('Error: Someone is already registered with this ID');</script>";
          
        }
        $stmt->close();
        $connect->close();   
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Sign Up</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Drag--Drop-Upload-Form.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="margin-bottom: 0px;margin-top: -2px;border-color: gray;">
    <div>
        <div class="header-dark" style="height: 216px;">
            <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
                <div class="container"><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse text-uppercase" id="navcol-1"><img class="mr-auto" src="assets/img/logo.png" onClick="location.href='mainpage.html'" style="height: 144px;"><span class="ml-auto navbar-text"><a class="btn btn-light action-button" role="button" href="login.php">Log In &nbsp;</a></span></div>
                </div>
            </nav>
        </div>
    </div>

<form method="post">
    <div style="margin-bottom: -6px;margin-top: -20px;background-color: white;"><label style="font-size: 32px;margin-left: 432px;margin-bottom: 13px;color: black;"><strong>Create an Account</strong></label>
       
<div class="container">
            <div class="row">
                <div class="col-md-6">
<form action="dataInsert.php"  method="post" enctype="multipart/form-data">        
<div class="row">

                        <div class="col" style="width: 40%;"><label>User Name</label><input class="border rounded shadow" type="text" name="userName"
title="can only contain numbers, letters and underscores!" style="margin-left: 103px;border: none;" required></div>
                    </div>
                    <div class="row">
                        <div class="col"><label>Employee ID</label><input class="border rounded shadow" type="text" name = "userID" style="margin-left: 91px;border: none;" required></div>
                    </div>
                    <div class="row">
                        <div class="col"><label>E-mail ID</label><input class="border rounded shadow" type="email" name = "mail"
title="Must contain '@' with domain name!"  style="margin-left: 117px;border: none;" required></div>
                    </div>
                    <div class="row">
                        <div class="col"><label>Mobile Number</label><input class="border rounded shadow" type="text" name = "number"
title="Must be like provided format!" style="margin-left: 69px;border: none;" ></div>
                    </div>
                    <div class="row">
                        <div class="col"><label>Password</label><input class="border rounded shadow" type="password" name = "pass" maxlength="14"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
title="Must contain at least one number and one uppercase and lowercase letter, and at least 6 or more characters" style="margin-left: 115px;border: none" required></div>
                    </div>
                    <div class="row">
                        <div class="col"><label>Confirm Password</label><input class="border rounded shadow" type="password" name = "confirmPass" maxlength="14"style="margin-left: 53px;border: none;" required></div>
                    </div>
                    <div class="row">
                        <div class="col"><label>Department</label>
                           
                        <select class="border rounded shadow" name="dept" style="margin-left: 88px;margin-top: -37px;margin-bottom: 11px;background-color: white;color: black;border: none;width: 208px;"required>
                            <option selected hidden value="">Select Code</option>
                            <option value="Hotel Management">Hotel Management</option>
                            <option value="Engineering">Engineering</option>
                            <option value="Nursing">Nursing</option>
                            <option value="Dental Science">Dental Science</option>
                            <option value="Pharmacy">Pharmacy</option>
                            <option value="Physiotherapy">Physiotherapy</option>
                            <option value="Medical section">Medical Science</option>
                            <option value="Management">Management</option>
                            <option value="Computer Applications">Computer Applications</option>
                           </select>
                     
                    </div>
                </div>

                <div class="row">
                    <div class="col"><label>Address</label><textarea class="border rounded shadow-lg" name="user_Add" style="margin-left: 120px;width: 214px;border: none;height: 82px;"></textarea></div>
                </div>
                <div class="row" style="min-height: 1px;">
                    <div class="col"><label class="col-form-label">User Picture</label></div>
                    <div class="col"></div>
                    <div class="col" style="margin-left: 178px;margin-bottom: 0px;width: 433px;height: 262px;padding-right: 44px;">
                        <div class="dashed_upload" style="height: 251px;width: 429px;margin-top: 1px;margin-bottom: 6px;"><div class="wrapper">
  <div class="drop">
    <div class="cont">
      <i class="fa fa-cloud-upload"></i>
      <div class="tit">
        Drag & Drop
      </div>
      <div class="desc">
        or
      </div>
      <div class="browse">
        click here to browse
      </div>
    </div>
    <output id="list"></output><input type="file" name="image" id="upFile" accept=".png,.gif,.jpg,.webp" required/>
  </div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script></div><img style="margin-top: -333px;margin-right: -78px;margin-left: -178px;width: 164px;height: 209px;background-color: white;"></div>
                </div>
            </div>
            <div class="col-md-6" style="margin-left: -4px;">
                <section class="border rounded-0 shadow-lg" style="margin-left: 98px;min-height: 1px;height: 403px;width: 460px;background-color: #0f58b5;"><img class="border rounded-circle shadow-lg" src="assets/img/signup.jpg" style="margin-left: 45px;margin-top: 32px;min-height: 2px;max-height: -22px;width: 311px;height: 264px;">
<label style="color: white;font-size: 12x;margin-left: 16px;margin-top: 10px;"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <em>&nbsp;Join the Virtual Community ! &nbsp;</em></strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
VC is the easiest way people with common interest where they can interact with each other and express their ideas.</label></section>
            </div>
            <!--<button class="btn btn-primary" type="submit" value="Submit" style="background-color: rgb(30, 169, 69) ; font-size: 22px; border: none; padding-left: 100px; padding-right: 100px;  margin-left: 450px; margin-bottom: 50px">Sign Up</button> -->
            <input type="submit" name="submit" value="Sign Up" style="background-color: rgb(30, 169, 69) ; font-size: 22px; border: none; padding-left: 100px; padding-right: 100px;  margin-left: 450px; margin-bottom: 80px />

        </div>
    </div>
    </div>
 
  </form>
 
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-animation.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>

<script>
function validateForm() {
 var f_name = document.forms["myForm"]["userName"].value;
 var f_ID = document.forms["myForm"]["userID"].value;
 var f_mail = document.forms["myForm"]["mail"].value;
 var f_pass = document.forms["myForm"]["pass"].value;
  var f_confirm = document.forms["myForm"]["confirmPass"].value;
   var f_dept = document.forms["myForm"]["dept"].value;

capitalLetter = /[A-Z]/;
lowerLetter = /[a-z]/;
userNameValidation = /^\w+$/;
numbers = /[0-9]/;


if (f_name == "" || f_ID == "" || f_mail == "" || f_pass == "" || f_confirm == "")
{
alert("Error: Please fill your respective fields..!");
return false;
}
if(!userNameValidation.test(myForm.userName.value))
{
alert("Error: Username must contain only letters, numbers and underscores!");
myForm.userName.focus();
return false;
}
if(myForm.userName.value.length > 15)
{
alert("Error: Username must be with in 15 chracters long!");
myForm.userName.focus();
return false;
}

if(myForm.pass.value != "" && myForm.pass.value == myForm.confirmPass.value)
{
if(myForm.pass.value.length < 6)
{
alert("Error: Password must contain at least six characters!");
myForm.pass.focus();
return false;
}
if(!capitalLetter.test(myForm.pass.value))
{
alert("Error: password must contain at least one uppercase letter (A-Z)!");
myForm.pass.focus();
return false;
}
if(myForm.userName.value == myForm.pass.value)
{
alert("Error: username and password must be different from each other!");
myForm.pass.focus();
return false;
}

if(!numbers.test(myForm.pass.value))
{
alert("Error: password must containts at least one number (0-9)!");
myForm.pass.focus();
return false;
}
if(!lowerLetter.test(myForm.pass.value))
{
alert("Error: password must contain at least one lowercase letter (a-z)!");
myForm.pass.focus();
return false; 
}

}
else
{
 alert("Error: Please check that you've entered right password in confirm password field!");
 myForm.confirmPass.focus();
 return false;
}

}


</script>
</body>

</html>