<?php

$host = 'localhost:3303';
$user = 'root';
$password = '';
$dbname = 'new_post';

$dsn = 'mysql:host='. $host . ';dbname='.$dbname;

$pdo = new PDO($dsn, $user, $password);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

if (isset($_POST['submit'])) {
    $image = $_FILES['file']['name'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $targetDir = "attachment/";
    $fileName = basename($_FILES['file']['name']);
    $targetPath = $targetDir.$fileName;

    $sql = 'INSERT INTO `posts`(`title`,`description`,`category`,`attachment`) VALUES(?,?,?,?)';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$title,$description,$category,$targetPath]);
    move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
}
?>