package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.solver.widgets.ResolutionDimension;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.IOException;
import java.util.regex.Pattern;

public class signUp extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[] clgDepartments = { "Hotel Management", "Engineering", "Nursing", "Dental Science", "Pharmacy", "Physiotherapy", "Medical Science",
    "Computer Applications"};
    Spinner dept;

    private Button signinButton;
    private EditText username, pass, address, employee_ID, email_ID;
    //defining AwesomeValidation object

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        dept = (Spinner) findViewById(R.id.department);
        signinButton = (Button)findViewById(R.id.signinBtn);
        username = (EditText)findViewById(R.id.ususrName);
        pass = (EditText)findViewById(R.id.usrPass);
        address = (EditText)findViewById(R.id.usrAddress);
        employee_ID = (EditText)findViewById(R.id.usrID);
        email_ID = (EditText)findViewById(R.id.usrMail);
        signinButton = (Button)findViewById(R.id.signinBtn);
        dept.setOnItemSelectedListener(this);

        signinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputValidations();
            }
        });

        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,clgDepartments);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        dept.setAdapter(aa);

    }

    public void inputValidations()
    {
        String nameOfUser = username.getText().toString();
        String IdOfUser = employee_ID.getText().toString();
        String emailOfUser = email_ID.getText().toString();
        String passwordOfUser = pass.getText().toString();
        String addressOfUser = address.getText().toString();
        String departmentOfUser = dept.getSelectedItem().toString();

        if(nameOfUser.equals("") ||
                IdOfUser.equals("") ||
                emailOfUser.equals("") ||
                passwordOfUser.equals("") ||
                addressOfUser.equals("")||
                departmentOfUser.equals(""))
        {
            Toast.makeText(getApplicationContext(), "Please fill the vacant fields..!", Toast.LENGTH_LONG).show();
        }
        else if(!emailOfUser.matches(String.valueOf(Patterns.EMAIL_ADDRESS)))
        {
            Toast.makeText(getApplicationContext(), "Please enter the valid E-mail address", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Welcome, "+nameOfUser, Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(signUp.this, MainActivity.class);
            startActivity(intent);
        }
    }
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
//        Toast.makeText(getApplicationContext(),clgDepartments[position] , Toast.LENGTH_LONG).show();
    }
    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
