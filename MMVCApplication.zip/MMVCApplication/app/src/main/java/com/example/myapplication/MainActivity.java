package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText nameofUser, passofUser;
    TextView signUpPage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        nameofUser = (EditText)findViewById(R.id.userId);
        passofUser = (EditText)findViewById(R.id.userpass);
        signUpPage = (TextView) findViewById(R.id.signUp);

         }


         public void onButtonClick(View view)
         {

             String user_ID = nameofUser.getText().toString();
             String user_Pass = passofUser.getText().toString();

             String type = "login";
             BackgroundWorker worker = new BackgroundWorker(this);
             worker.execute(type, user_ID, user_Pass);


         }
}
